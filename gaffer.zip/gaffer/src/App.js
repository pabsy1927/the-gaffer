import { useState, useEffect, useRef } from "react";
import { dbGet, dbSet, dbGetShared, dbSetShared, dbDelShared } from "./firebase";
import { getDatabase, ref, onValue } from "firebase/database";

// ─── Constants ────────────────────────────────────────────────────────────────
const POSITIONS = ["GK","DEF","MID","FWD","ANY"];
const TABS      = ["Squad","Availability","Payments","Teams","History","Stats"];
const posColor  = p => ({GK:"#f59e0b",DEF:"#3b82f6",MID:"#22c55e",FWD:"#ef4444",ANY:"#a855f7"}[p]||"#888");
const RED  = "#ef4444";
const BLUE = "#3b82f6";

const INIT_PLAYERS = [
  {id:1,name:"Jamie Clarke",pos:"GK", skill:7,games:12,active:true,paid:false},
  {id:2,name:"Marcus Webb", pos:"DEF",skill:8,games:15,active:true,paid:false},
  {id:3,name:"Liam Torres", pos:"MID",skill:9,games:10,active:true,paid:false},
  {id:4,name:"Danny Shaw",  pos:"FWD",skill:8,games:14,active:true,paid:false},
  {id:5,name:"Karl Reid",   pos:"MID",skill:6,games:8, active:true,paid:false},
];

// ─── Shared UI ────────────────────────────────────────────────────────────────
function Btn({children,onClick,bg="#00e676",fg="#000",sm,danger,ghost,style:sx={}}){
  return <button onClick={onClick} style={{background:danger?"rgba(239,68,68,0.15)":ghost?"rgba(255,255,255,0.08)":bg,color:danger?"#ef4444":ghost?"#ccc":fg,border:"none",borderRadius:8,padding:sm?"6px 12px":"9px 18px",fontWeight:700,cursor:"pointer",fontSize:sm?12:13,fontFamily:"inherit",letterSpacing:.4,transition:"all .15s",...sx}}>{children}</button>;
}
function SkillDots({value}){
  return <div style={{display:"flex",gap:3,alignItems:"center"}}>{Array.from({length:10},(_,i)=><div key={i} style={{width:14,height:14,borderRadius:3,background:i<value?`hsl(${115-i*9},75%,48%)`:"rgba(255,255,255,0.1)"}}/>)}<span style={{fontSize:12,color:"#888",marginLeft:4}}>{value}/10</span></div>;
}
function SLabel({children}){return <div style={{fontSize:10,letterSpacing:2,color:"rgba(255,255,255,0.4)",textTransform:"uppercase",margin:"20px 0 8px"}}>{children}</div>;}
const iStyle={background:"rgba(255,255,255,0.07)",border:"1px solid rgba(255,255,255,0.15)",color:"#fff",borderRadius:8,padding:"9px 12px",fontSize:14,outline:"none",fontFamily:"inherit",width:"100%",boxSizing:"border-box"};
const selStyle={...iStyle,background:"#151f2e"};

// ─── Poll View (for players voting via link) ──────────────────────────────────
function PollView({pollId}){
  const [poll,setPoll]       = useState(null);
  const [players,setPlayers] = useState([]);
  const [votes,setVotes]     = useState({});
  const [voted,setVoted]     = useState(null);
  const [loading,setLoading] = useState(true);

  useEffect(()=>{
    // Load poll info once
    (async()=>{
      const p  = await dbGetShared("poll_"+pollId, null);
      const pl = await dbGet("players", []);
      setPoll(p);
      setPlayers(Array.isArray(pl) ? pl.filter(x=>x.active) : []);
      setLoading(false);
    })();
    // Live-listen to votes via Firebase realtime
    const db   = getDatabase();
    const vRef = ref(db, "shared/votes_"+pollId);
    const unsub = onValue(vRef, snap => {
      setVotes(snap.exists() ? snap.val() : {});
    });
    return () => unsub();
  },[pollId]);

  const vote = async(playerId, status) => {
    const nv = {...votes,[playerId]:status};
    setVotes(nv); setVoted(playerId);
    await dbSetShared("votes_"+pollId, nv);
    setTimeout(()=>setVoted(null),1500);
  };

  const inCount  = Object.values(votes).filter(v=>v==="in").length;
  const outCount = Object.values(votes).filter(v=>v==="out").length;

  if(loading) return(
    <div style={{minHeight:"100vh",background:"#0a0f1a",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:12,color:"#fff",fontFamily:"sans-serif"}}>
      <div style={{fontSize:44}}>⚽</div>
      <div style={{color:"#00e676",letterSpacing:2}}>Loading poll...</div>
    </div>
  );
  if(!poll) return(
    <div style={{minHeight:"100vh",background:"#0a0f1a",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:16,color:"#fff",fontFamily:"'Barlow Condensed',sans-serif",padding:24,textAlign:"center"}}>
      <div style={{fontSize:52}}>❌</div>
      <div style={{fontSize:24,fontWeight:800}}>Poll not found</div>
      <div style={{color:"rgba(255,255,255,0.4)"}}>This poll may have been closed by the organiser.</div>
    </div>
  );

  return(
    <div style={{minHeight:"100vh",background:"#0a0f1a",fontFamily:"'Barlow Condensed',sans-serif",color:"#fff"}}>
      <div style={{background:"linear-gradient(135deg,#0c1e10,#0a0f1a)",borderBottom:"1px solid rgba(255,255,255,0.07)",padding:"24px 20px"}}>
        <div style={{maxWidth:480,margin:"0 auto"}}>
          <div style={{fontSize:10,letterSpacing:4,color:"#00e676",marginBottom:4}}>⚽ THE GAFFER</div>
          <div style={{fontSize:28,fontWeight:900}}>{poll.title}</div>
          <div style={{fontSize:14,color:"rgba(255,255,255,0.45)",marginTop:4}}>{poll.date}</div>
        </div>
      </div>
      <div style={{maxWidth:480,margin:"0 auto",padding:"20px 16px 60px"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:22}}>
          <div style={{background:"rgba(34,197,94,0.1)",border:"1px solid rgba(34,197,94,0.3)",borderRadius:14,padding:"16px 0",textAlign:"center"}}>
            <div style={{fontSize:36,fontWeight:900,color:"#22c55e"}}>{inCount}</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.5)",letterSpacing:1}}>IN ✅</div>
          </div>
          <div style={{background:"rgba(239,68,68,0.1)",border:"1px solid rgba(239,68,68,0.3)",borderRadius:14,padding:"16px 0",textAlign:"center"}}>
            <div style={{fontSize:36,fontWeight:900,color:"#ef4444"}}>{outCount}</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.5)",letterSpacing:1}}>OUT ❌</div>
          </div>
        </div>
        <div style={{fontSize:13,color:"rgba(255,255,255,0.4)",marginBottom:16,textAlign:"center"}}>Tap your name then your answer — updates instantly 🔄</div>
        {players.map(p=>{
          const v=votes[p.id];
          return(
            <div key={p.id} style={{background:v==="in"?"rgba(34,197,94,0.08)":v==="out"?"rgba(239,68,68,0.08)":"rgba(255,255,255,0.04)",border:"1px solid "+(v==="in"?"rgba(34,197,94,0.3)":v==="out"?"rgba(239,68,68,0.3)":"rgba(255,255,255,0.08)"),borderRadius:13,padding:"14px 16px",marginBottom:10,transition:"all .3s"}}>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <div style={{width:40,height:40,borderRadius:10,background:posColor(p.pos)+"18",border:"2px solid "+posColor(p.pos)+"45",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:posColor(p.pos),flexShrink:0}}>{p.pos}</div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:800,fontSize:17}}>{p.name}</div>
                  {v  && <div style={{fontSize:12,color:v==="in"?"#22c55e":"#ef4444",marginTop:2,fontWeight:700}}>{voted===p.id?"✓ Saved!":(v==="in"?"✅ In":"❌ Out")}</div>}
                  {!v && <div style={{fontSize:12,color:"rgba(255,255,255,0.3)",marginTop:2}}>Not voted yet</div>}
                </div>
                <div style={{display:"flex",gap:8,flexShrink:0}}>
                  <button onClick={()=>vote(p.id,"in")}  style={{background:v==="in" ?"#22c55e":"rgba(34,197,94,0.15)", color:v==="in" ?"#000":"#22c55e",border:"none",borderRadius:9,padding:"10px 18px",fontWeight:800,fontSize:14,cursor:"pointer",fontFamily:"inherit",transition:"all .2s",minWidth:52}}>IN</button>
                  <button onClick={()=>vote(p.id,"out")} style={{background:v==="out"?"#ef4444":"rgba(239,68,68,0.15)",color:v==="out"?"#fff":"#ef4444",border:"none",borderRadius:9,padding:"10px 18px",fontWeight:800,fontSize:14,cursor:"pointer",fontFamily:"inherit",transition:"all .2s",minWidth:52}}>OUT</button>
                </div>
              </div>
            </div>
          );
        })}
        {inCount>0&&(
          <div style={{marginTop:16,background:"rgba(34,197,94,0.06)",border:"1px solid rgba(34,197,94,0.2)",borderRadius:13,padding:16}}>
            <div style={{fontSize:11,letterSpacing:2,color:"#22c55e",marginBottom:8}}>✅ IN SO FAR</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:7}}>{players.filter(p=>votes[p.id]==="in").map(p=><span key={p.id} style={{background:"rgba(34,197,94,0.15)",color:"#22c55e",border:"1px solid rgba(34,197,94,0.3)",padding:"4px 12px",borderRadius:20,fontSize:13,fontWeight:700}}>{p.name}</span>)}</div>
          </div>
        )}
        <div style={{marginTop:20,textAlign:"center",fontSize:12,color:"rgba(255,255,255,0.2)"}}>Powered by The Gaffer ⚽</div>
      </div>
    </div>
  );
}

// ─── Router ───────────────────────────────────────────────────────────────────
export default function App(){
  const params   = new URLSearchParams(window.location.search);
  const pollParam = params.get("poll");
  if(pollParam) return <PollView pollId={pollParam}/>;
  return <GafferApp/>;
}

// ─── Main Gaffer App ──────────────────────────────────────────────────────────
function GafferApp(){
  const [ready,        setReady]        = useState(false);
  const [tab,          setTab]          = useState("Squad");
  const [players,      setPlayers]      = useState([]);
  const [sessions,     setSessions]     = useState([]);
  const [avail,        setAvail]        = useState({});
  const [editId,       setEditId]       = useState(null);
  const [editF,        setEditF]        = useState({});
  const [addOpen,      setAddOpen]      = useState(false);
  const [newP,         setNewP]         = useState({name:"",pos:"MID",skill:5,games:0,active:true,paid:false});
  const [confirmId,    setConfirmId]    = useState(null);
  const [teams,        setTeams]        = useState(null);
  const [sessionOpen,  setSessionOpen]  = useState(false);
  const [sf,           setSf]           = useState({date:"",result:"",notes:"",ids:[]});
  const [payLabel,     setPayLabel]     = useState("");
  const [activePoll,   setActivePoll]   = useState(null);
  const [pollVotes,    setPollVotes]    = useState({});
  const [pollCopied,   setPollCopied]   = useState(false);
  const didLoad = useRef(false);

  const nextWed = () => {
    const d=new Date(); const diff=(3-d.getDay()+7)%7||7; d.setDate(d.getDate()+diff);
    return d.toISOString().slice(0,10);
  };

  // ── Load from Firebase ──
  useEffect(()=>{
    (async()=>{
      const p  = await dbGet("players",  INIT_PLAYERS);
      const s  = await dbGet("sessions", []);
      const a  = await dbGet("avail",    {});
      const ap = await dbGet("activepoll", null);
      setPlayers(Array.isArray(p)?p:INIT_PLAYERS);
      setSessions(Array.isArray(s)?s:[]);
      setAvail(a||{});
      setActivePoll(ap);
      setSf({date:nextWed(),result:"",notes:"",ids:[]});
      setPayLabel("Week of "+new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}));
      setReady(true);
      didLoad.current=true;
    })();
  },[]);

  // ── Auto-save to Firebase ──
  useEffect(()=>{ if(didLoad.current) dbSet("players",  players);  },[players]);
  useEffect(()=>{ if(didLoad.current) dbSet("sessions", sessions); },[sessions]);
  useEffect(()=>{ if(ready)           dbSet("avail",    avail);    },[avail,ready]);
  useEffect(()=>{ if(ready)           dbSet("activepoll", activePoll); },[activePoll,ready]);

  // ── Live poll vote listener ──
  useEffect(()=>{
    if(!activePoll) return;
    const db    = getDatabase();
    const vRef  = ref(db, "shared/votes_"+activePoll.id);
    const unsub = onValue(vRef, snap=>{
      setPollVotes(snap.exists()?snap.val():{});
    });
    return ()=>unsub();
  },[activePoll]);

  if(!ready) return(
    <div style={{minHeight:"100vh",background:"#0a0f1a",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:12,color:"#fff",fontFamily:"sans-serif"}}>
      <div style={{fontSize:44}}>⚽</div>
      <div style={{color:"#00e676",letterSpacing:2}}>LOADING...</div>
    </div>
  );

  // ── Derived ──
  const active   = players.filter(p=>p.active);
  const inP      = active.filter(p=>avail[p.id]==="in");
  const outP     = active.filter(p=>avail[p.id]==="out");
  const unknownP = active.filter(p=>!avail[p.id]);
  const paidN    = active.filter(p=>p.paid).length;
  const avgSkill = arr=>arr.length?(arr.reduce((s,p)=>s+p.skill,0)/arr.length).toFixed(1):"–";
  const pc       = posColor;
  const pollInCount  = Object.values(pollVotes).filter(v=>v==="in").length;
  const pollOutCount = Object.values(pollVotes).filter(v=>v==="out").length;
  const pollLink     = activePoll ? window.location.origin+window.location.pathname+"?poll="+activePoll.id : "";

  // ── Squad ──
  const startEdit = p  => { setConfirmId(null); setEditId(p.id); setEditF({...p}); };
  const saveEdit  = () => { setPlayers(pl=>pl.map(p=>p.id===editId?{...editF}:p)); setEditId(null); };
  const doRemove  = id => { setPlayers(prev=>prev.filter(p=>p.id!==id)); setConfirmId(null); };
  const addPlayer = () => {
    if(!newP.name.trim())return;
    setPlayers(pl=>[...pl,{...newP,id:Date.now()}]);
    setNewP({name:"",pos:"MID",skill:5,games:0,active:true,paid:false});
    setAddOpen(false);
  };

  // ── Teams — Bash→Red, Mike→Blue ──
  const pool = () => inP.length>=2 ? inP : active;
  const applyPins = (t1,t2,poolList) => {
    const bash=poolList.find(p=>p.name.toLowerCase().startsWith("bash")&&p.pos==="GK");
    const mike=poolList.find(p=>p.name.toLowerCase().startsWith("mike")&&p.pos==="GK");
    let a=[...t1],b=[...t2];
    if(bash){b=b.filter(p=>p.id!==bash.id);if(!a.find(p=>p.id===bash.id)){a=a.filter(p=>p.id!==bash.id);a.unshift(bash);}}
    if(mike){a=a.filter(p=>p.id!==mike.id);if(!b.find(p=>p.id===mike.id)){b=b.filter(p=>p.id!==mike.id);b.unshift(mike);}}
    return[a,b];
  };
  const genRandom  = () => { const p=[...pool()].sort(()=>Math.random()-.5); const[a,b]=applyPins(p.filter((_,i)=>i%2===0),p.filter((_,i)=>i%2===1),pool()); setTeams([a,b]); };
  const genBalance = () => { const p=[...pool()].sort((a,b)=>b.skill-a.skill); const t1=[],t2=[]; p.forEach((x,i)=>(i%2===0?t1:t2).push(x)); const[a,b]=applyPins(t1,t2,pool()); setTeams([a,b]); };

  // ── Session ──
  const logSession = () => {
    setSessions(s=>[{id:Date.now(),date:sf.date,result:sf.result,notes:sf.notes,playerIds:sf.ids,count:sf.ids.length},...s]);
    setPlayers(pl=>pl.map(p=>sf.ids.includes(p.id)?{...p,games:p.games+1}:p));
    setSessionOpen(false); setSf({date:nextWed(),result:"",notes:"",ids:[]});
  };

  // ── Poll ──
  const createPoll = async () => {
    const id=Date.now().toString(36);
    const nw=new Date(); const diff=(3-nw.getDay()+7)%7||7; nw.setDate(nw.getDate()+diff);
    const date=nw.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long"})+" at 7pm";
    const poll={id,title:"⚽ Football this week",date};
    await dbSetShared("poll_"+id, poll);
    await dbSetShared("votes_"+id, {});
    setActivePoll(poll); setPollVotes({});
  };
  const closePoll = async () => {
    if(!activePoll)return;
    const newAvail={};
    active.forEach(p=>{ if(pollVotes[p.id]) newAvail[p.id]=pollVotes[p.id]; });
    setAvail(newAvail);
    await dbDelShared("poll_"+activePoll.id);
    await dbDelShared("votes_"+activePoll.id);
    setActivePoll(null); setPollVotes({});
  };
  const copyLink = () => {
    navigator.clipboard.writeText(pollLink).then(()=>{ setPollCopied(true); setTimeout(()=>setPollCopied(false),2000); });
  };
  const whatsAppMsg = () => {
    const msg=["⚽ *Football this week — "+(activePoll?.date||"")+"*","","Tap the link to vote IN or OUT 👇","",pollLink,"","Results update live in real time!"].join("\n");
    return "https://wa.me/?text="+encodeURIComponent(msg);
  };

  return(
    <div style={{minHeight:"100vh",background:"#0a0f1a",fontFamily:"'Barlow Condensed',sans-serif",color:"#fff"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:#1c3025;border-radius:4px}
        .htab{background:none;border:none;cursor:pointer;font-family:inherit;font-size:13px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;padding:12px 14px;color:rgba(255,255,255,0.35);border-bottom:3px solid transparent;transition:all .2s;white-space:nowrap}
        .htab.on{color:#00e676;border-bottom-color:#00e676}.htab:hover{color:#fff}
        .pcard{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:13px;padding:15px;margin-bottom:10px;transition:background .15s}
        .pcard:hover{background:rgba(255,255,255,0.065)}
        .mbg{position:fixed;inset:0;background:rgba(0,0,0,0.78);display:flex;align-items:center;justify-content:center;z-index:300;padding:16px}
        .mbox{background:#111c2a;border:1px solid rgba(255,255,255,0.13);border-radius:18px;padding:26px;width:370px;max-width:100%;max-height:90vh;overflow-y:auto}
        input[type=range]{accent-color:#00e676;width:100%}
        input[type=checkbox]{accent-color:#00e676;width:15px;height:15px;cursor:pointer}
        .abt{border:none;border-radius:8px;padding:7px 16px;font-family:inherit;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s}
        @keyframes fi{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}.fi{animation:fi .25s ease}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}.pulse{animation:pulse 2s infinite}
      `}</style>

      {/* HEADER */}
      <div style={{background:"linear-gradient(135deg,#0c1e10,#0a0f1a)",borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
        <div style={{maxWidth:740,margin:"0 auto",padding:"20px 16px 0"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:18}}>
            <div>
              <div style={{fontSize:10,letterSpacing:4,color:"#00e676",textTransform:"uppercase",marginBottom:3}}>⚽ 5-a-side Manager</div>
              <div style={{fontSize:34,fontWeight:900,letterSpacing:1}}>THE GAFFER</div>
            </div>
            <div style={{display:"flex",gap:18,textAlign:"center"}}>
              {[{v:active.length,l:"SQUAD",c:"#00e676"},{v:avgSkill(active),l:"AVG SKL",c:"#f59e0b"},{v:inP.length,l:"IN",c:inP.length>0?BLUE:"rgba(255,255,255,0.25)"},{v:paidN,l:"PAID",c:paidN>0?"#22c55e":"rgba(255,255,255,0.25)"}].map(x=>(
                <div key={x.l}><div style={{fontSize:24,fontWeight:800,color:x.c,lineHeight:1}}>{x.v}</div><div style={{fontSize:9,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>{x.l}</div></div>
              ))}
            </div>
          </div>
          <div style={{display:"flex",overflowX:"auto"}}>
            {TABS.map(t=><button key={t} className={"htab"+(tab===t?" on":"")} onClick={()=>setTab(t)}>{t}{t==="Availability"&&activePoll?" 🔴":""}</button>)}
          </div>
        </div>
      </div>

      <div style={{maxWidth:740,margin:"0 auto",padding:"22px 16px 60px"}} className="fi">

        {/* ══ SQUAD ══ */}
        {tab==="Squad"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <div style={{fontSize:20,fontWeight:800}}>Squad ({players.length})</div>
              <Btn onClick={()=>setAddOpen(true)}>+ Add Player</Btn>
            </div>
            {players.map(p=>(
              <div key={p.id} className="pcard">
                {editId===p.id?(
                  <div style={{display:"flex",flexDirection:"column",gap:11}}>
                    <div style={{display:"flex",gap:8}}>
                      <input style={iStyle} value={editF.name} onChange={e=>setEditF(f=>({...f,name:e.target.value}))} placeholder="Name"/>
                      <select style={{...selStyle,width:85}} value={editF.pos} onChange={e=>setEditF(f=>({...f,pos:e.target.value}))}>
                        {POSITIONS.map(x=><option key={x}>{x}</option>)}
                      </select>
                    </div>
                    <div><div style={{fontSize:11,color:"#888",marginBottom:5}}>SKILL: {editF.skill}/10</div><input type="range" min={1} max={10} value={editF.skill} onChange={e=>setEditF(f=>({...f,skill:+e.target.value}))}/></div>
                    <div style={{display:"flex",gap:8}}>
                      <div style={{flex:1}}><div style={{fontSize:11,color:"#888",marginBottom:4}}>GAMES</div><input style={iStyle} type="number" value={editF.games} onChange={e=>setEditF(f=>({...f,games:+e.target.value}))}/></div>
                      <div style={{flex:1,display:"flex",alignItems:"flex-end",paddingBottom:2}}><label style={{display:"flex",alignItems:"center",gap:8,cursor:"pointer"}}><input type="checkbox" checked={editF.active} onChange={e=>setEditF(f=>({...f,active:e.target.checked}))}/><span style={{fontSize:14}}>Active</span></label></div>
                    </div>
                    <div style={{display:"flex",gap:8}}><Btn onClick={saveEdit}>Save</Btn><Btn ghost onClick={()=>setEditId(null)}>Cancel</Btn></div>
                  </div>
                ):(
                  <div style={{display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:44,height:44,borderRadius:11,background:pc(p.pos)+"18",border:"2px solid "+pc(p.pos)+"45",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:pc(p.pos),flexShrink:0}}>{p.pos}</div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:5,flexWrap:"wrap"}}>
                        <span style={{fontWeight:700,fontSize:17}}>{p.name}</span>
                        {!p.active&&<span style={{fontSize:10,background:"rgba(255,255,255,0.1)",color:"#888",padding:"2px 8px",borderRadius:20,letterSpacing:1}}>INACTIVE</span>}
                      </div>
                      <SkillDots value={p.skill}/>
                      <div style={{fontSize:12,color:"rgba(255,255,255,0.4)",marginTop:5}}>🎮 {p.games} game{p.games!==1?"s":""}</div>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",gap:6,flexShrink:0}}>
                      <Btn ghost sm onClick={()=>startEdit(p)}>Edit</Btn>
                      {confirmId===p.id?(
                        <div style={{display:"flex",gap:5}}><Btn sm bg={RED} fg="#fff" onClick={()=>doRemove(p.id)}>Yes</Btn><Btn sm ghost onClick={()=>setConfirmId(null)}>No</Btn></div>
                      ):(
                        <Btn danger sm onClick={()=>setConfirmId(p.id)}>Remove</Btn>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ══ AVAILABILITY ══ */}
        {tab==="Availability"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <div style={{fontSize:20,fontWeight:800}}>Who's In?</div>
              <Btn ghost sm onClick={()=>setAvail({})}>Reset</Btn>
            </div>
            {!activePoll?(
              <div style={{background:"linear-gradient(135deg,rgba(0,230,118,0.08),rgba(37,211,102,0.05))",border:"1px solid rgba(0,230,118,0.2)",borderRadius:16,padding:20,marginBottom:22}}>
                <div style={{fontSize:16,fontWeight:800,marginBottom:6}}>📲 Live Poll</div>
                <div style={{fontSize:14,color:"rgba(255,255,255,0.5)",marginBottom:16,lineHeight:1.5}}>Create a poll link to send to your WhatsApp group. Players tap IN or OUT — results appear here in real time.</div>
                <Btn bg="#00e676" fg="#000" onClick={createPoll} style={{width:"100%",padding:"12px",fontSize:15}}>🚀 Create This Week's Poll</Btn>
              </div>
            ):(
              <div style={{background:"rgba(0,230,118,0.06)",border:"1px solid rgba(0,230,118,0.25)",borderRadius:16,padding:20,marginBottom:22}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
                  <div>
                    <div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:8,height:8,borderRadius:"50%",background:"#00e676"}} className="pulse"/><span style={{fontSize:15,fontWeight:800}}>Poll Live</span></div>
                    <div style={{fontSize:12,color:"rgba(255,255,255,0.4)",marginTop:2}}>{activePoll.date}</div>
                  </div>
                  <div style={{display:"flex",gap:16,textAlign:"center"}}>
                    <div><div style={{fontSize:26,fontWeight:900,color:"#22c55e",lineHeight:1}}>{pollInCount}</div><div style={{fontSize:9,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>IN</div></div>
                    <div><div style={{fontSize:26,fontWeight:900,color:RED,lineHeight:1}}>{pollOutCount}</div><div style={{fontSize:9,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>OUT</div></div>
                    <div><div style={{fontSize:26,fontWeight:900,color:"rgba(255,255,255,0.3)",lineHeight:1}}>{active.length-pollInCount-pollOutCount}</div><div style={{fontSize:9,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>PENDING</div></div>
                  </div>
                </div>
                <div style={{background:"rgba(0,0,0,0.3)",borderRadius:10,padding:"10px 14px",marginBottom:12,display:"flex",alignItems:"center",gap:10}}>
                  <div style={{flex:1,fontSize:12,color:"rgba(255,255,255,0.5)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{pollLink}</div>
                  <button onClick={copyLink} style={{background:pollCopied?"#22c55e":"rgba(255,255,255,0.1)",color:pollCopied?"#000":"#fff",border:"none",borderRadius:7,padding:"6px 14px",fontWeight:700,cursor:"pointer",fontSize:12,fontFamily:"inherit",whiteSpace:"nowrap",transition:"all .2s",flexShrink:0}}>{pollCopied?"✓ Copied!":"Copy Link"}</button>
                </div>
                <div style={{display:"flex",gap:8}}>
                  <a href={whatsAppMsg()} target="_blank" rel="noopener noreferrer" style={{flex:1,background:"#25D366",color:"#fff",border:"none",borderRadius:9,padding:"11px",fontWeight:800,fontSize:14,fontFamily:"inherit",textDecoration:"none",textAlign:"center",display:"block"}}>📲 Send to WhatsApp</a>
                  <Btn ghost sm onClick={closePoll} style={{padding:"11px 16px",fontSize:13}}>Close &amp; Import</Btn>
                </div>
                {(pollInCount+pollOutCount)>0&&(
                  <div style={{marginTop:14,borderTop:"1px solid rgba(255,255,255,0.08)",paddingTop:14}}>
                    <div style={{fontSize:10,letterSpacing:2,color:"rgba(255,255,255,0.4)",marginBottom:10}}>LIVE RESPONSES</div>
                    <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                      {active.filter(p=>pollVotes[p.id]).map(p=>(
                        <span key={p.id} style={{background:pollVotes[p.id]==="in"?"rgba(34,197,94,0.15)":"rgba(239,68,68,0.15)",color:pollVotes[p.id]==="in"?"#22c55e":RED,border:"1px solid "+(pollVotes[p.id]==="in"?"rgba(34,197,94,0.3)":"rgba(239,68,68,0.3)"),padding:"4px 12px",borderRadius:20,fontSize:12,fontWeight:700}}>
                          {pollVotes[p.id]==="in"?"✅":"❌"} {p.name}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            <div style={{fontSize:10,letterSpacing:2,color:"rgba(255,255,255,0.3)",marginBottom:10}}>OR UPDATE MANUALLY</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:18}}>
              {[{l:"IN",c:"#22c55e",n:inP.length},{l:"OUT",c:RED,n:outP.length},{l:"UNKNOWN",c:"rgba(255,255,255,0.3)",n:unknownP.length}].map(x=>(
                <div key={x.l} style={{background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:12,padding:"12px 0",textAlign:"center"}}>
                  <div style={{fontSize:22,fontWeight:800,color:x.c}}>{x.n}</div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>{x.l}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:8,marginBottom:16}}>
              <Btn bg="rgba(34,197,94,0.15)" fg="#22c55e" sm onClick={()=>{const o={};active.forEach(p=>o[p.id]="in");setAvail(o);}}>✓ All In</Btn>
              <Btn ghost sm onClick={()=>setAvail({})}>Clear</Btn>
            </div>
            {active.map(p=>{
              const s=avail[p.id];
              return(
                <div key={p.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
                  <div style={{width:36,height:36,borderRadius:9,background:pc(p.pos)+"18",border:"2px solid "+pc(p.pos)+"40",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:pc(p.pos),flexShrink:0}}>{p.pos}</div>
                  <div style={{flex:1}}><div style={{fontWeight:700}}>{p.name}</div><div style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>★{p.skill} · {p.games} games</div></div>
                  <div style={{display:"flex",gap:6}}>
                    {[["in","IN","#22c55e"],["out","OUT",RED]].map(([val,lbl,col])=>(
                      <button key={val} className="abt" onClick={()=>setAvail(a=>({...a,[p.id]:a[p.id]===val?undefined:val}))}
                        style={{background:s===val?col:col+"18",color:s===val?(val==="out"?"#fff":"#000"):col,minWidth:50}}>{lbl}</button>
                    ))}
                  </div>
                </div>
              );
            })}
            {inP.length>0&&(
              <div style={{marginTop:20,background:"rgba(34,197,94,0.07)",border:"1px solid rgba(34,197,94,0.2)",borderRadius:13,padding:16}}>
                <div style={{fontSize:10,letterSpacing:2,color:"#22c55e",marginBottom:8}}>📋 CONFIRMED IN</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>{inP.map(p=><span key={p.id} style={{background:"rgba(34,197,94,0.15)",color:"#22c55e",border:"1px solid rgba(34,197,94,0.3)",padding:"4px 12px",borderRadius:20,fontSize:12,fontWeight:700}}>{p.name}</span>)}</div>
              </div>
            )}
          </div>
        )}

        {/* ══ PAYMENTS ══ */}
        {tab==="Payments"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:10}}>
              <div style={{fontSize:20,fontWeight:800}}>Payments</div>
              <input value={payLabel} onChange={e=>setPayLabel(e.target.value)} style={{...iStyle,width:"auto",fontSize:13,padding:"7px 11px"}}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>
              {[{l:"PAID",c:"#22c55e",bg:"rgba(34,197,94,0.08)",bc:"rgba(34,197,94,0.2)",v:paidN},{l:"UNPAID",c:RED,bg:"rgba(239,68,68,0.08)",bc:"rgba(239,68,68,0.2)",v:active.length-paidN},{l:"TOTAL",c:"#fff",bg:"rgba(255,255,255,0.04)",bc:"rgba(255,255,255,0.1)",v:active.length}].map(x=>(
                <div key={x.l} style={{background:x.bg,border:"1px solid "+x.bc,borderRadius:12,padding:"13px 0",textAlign:"center"}}>
                  <div style={{fontSize:26,fontWeight:800,color:x.c}}>{x.v}</div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.4)",letterSpacing:1}}>{x.l}</div>
                </div>
              ))}
            </div>
            <div style={{background:"rgba(255,255,255,0.08)",borderRadius:8,height:9,marginBottom:16,overflow:"hidden"}}>
              <div style={{height:"100%",width:(active.length?(paidN/active.length)*100:0)+"%",background:"linear-gradient(90deg,#22c55e,#00bcd4)",transition:"width .4s",borderRadius:8}}/>
            </div>
            <div style={{display:"flex",gap:8,marginBottom:20}}>
              <Btn onClick={()=>setPlayers(pl=>pl.map(p=>({...p,paid:true})))}>✓ All Paid</Btn>
              <Btn ghost onClick={()=>setPlayers(pl=>pl.map(p=>({...p,paid:false})))}>Reset</Btn>
            </div>
            {active.map(p=>(
              <div key={p.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 0",borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
                <div style={{width:34,height:34,borderRadius:9,background:pc(p.pos)+"18",border:"2px solid "+pc(p.pos)+"40",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:pc(p.pos),flexShrink:0}}>{p.pos}</div>
                <div style={{flex:1}}><div style={{fontWeight:700}}>{p.name}</div><div style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>{p.games} games</div></div>
                <button onClick={()=>setPlayers(pl=>pl.map(q=>q.id===p.id?{...q,paid:!q.paid}:q))}
                  style={{background:p.paid?"#22c55e":"rgba(255,255,255,0.08)",color:p.paid?"#000":"#888",border:"none",borderRadius:8,padding:"8px 18px",fontWeight:700,cursor:"pointer",fontSize:13,fontFamily:"inherit",minWidth:82,transition:"all .2s"}}>
                  {p.paid?"✓ PAID":"UNPAID"}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ══ TEAMS ══ */}
        {tab==="Teams"&&(
          <div>
            <div style={{fontSize:20,fontWeight:800,marginBottom:6}}>Team Picker</div>
            <div style={{fontSize:13,color:inP.length>=2?"#22c55e":"rgba(255,255,255,0.4)",marginBottom:14}}>
              {inP.length>=2?"Using "+inP.length+" confirmed players ✅":"Using all "+active.length+" active players"}
            </div>
            {(pool().some(p=>p.name.toLowerCase().startsWith("bash")&&p.pos==="GK")||pool().some(p=>p.name.toLowerCase().startsWith("mike")&&p.pos==="GK"))&&(
              <div style={{background:"rgba(245,158,11,0.08)",border:"1px solid rgba(245,158,11,0.2)",borderRadius:10,padding:"9px 14px",marginBottom:14,fontSize:13,color:"#f59e0b"}}>
                📌 GK pins — {pool().find(p=>p.name.toLowerCase().startsWith("bash")&&p.pos==="GK")?.name} → Team Red · {pool().find(p=>p.name.toLowerCase().startsWith("mike")&&p.pos==="GK")?.name} → Team Blue
              </div>
            )}
            <div style={{display:"flex",gap:10,marginBottom:24,flexWrap:"wrap"}}>
              <Btn bg={RED} fg="#fff" onClick={genRandom}>🎲 Random</Btn>
              <Btn bg={BLUE} fg="#fff" onClick={genBalance}>⚖️ Balanced</Btn>
              {teams&&<Btn ghost onClick={()=>setTeams(null)}>Clear</Btn>}
            </div>
            {!teams&&<div style={{textAlign:"center",padding:"60px 0",color:"rgba(255,255,255,0.2)"}}><div style={{fontSize:50}}>⚽</div><div style={{marginTop:12}}>Pick a generation method</div></div>}
            {teams&&(
              <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
                <div style={{flex:"1 1 280px",background:"rgba(255,255,255,0.04)",border:"2px solid #ef444455",borderRadius:13,padding:16}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:13}}>
                    <div style={{display:"flex",alignItems:"center",gap:10}}>
                      <div style={{width:18,height:18,borderRadius:4,background:RED,flexShrink:0}}/>
                      <div style={{fontSize:19,fontWeight:800,color:RED}}>TEAM RED</div>
                    </div>
                    <div style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>Avg ★{avgSkill(teams[0])}</div>
                  </div>
                  {teams[0].map(p=>(
                    <div key={p.id} style={{display:"flex",alignItems:"center",gap:9,padding:"7px 0",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                      <div style={{width:28,height:28,borderRadius:7,background:pc(p.pos)+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:pc(p.pos)}}>{p.pos}</div>
                      <span style={{flex:1,fontWeight:700,fontSize:15}}>{p.name}</span>
                      {p.pos==="GK"&&<span style={{fontSize:10,background:"#ef444422",color:RED,border:"1px solid #ef444444",padding:"2px 7px",borderRadius:10,fontWeight:700}}>GK</span>}
                      <span style={{color:"#f59e0b",fontSize:12}}>★{p.skill}</span>
                    </div>
                  ))}
                  <div style={{marginTop:11,padding:"8px 11px",background:"#ef444410",borderRadius:8,display:"flex",justifyContent:"space-between",fontSize:11,color:"rgba(255,255,255,0.35)"}}>
                    <span>{teams[0].length} players</span><span>Avg {avgSkill(teams[0])}/10</span>
                  </div>
                </div>
                <div style={{flex:"1 1 280px",background:"rgba(255,255,255,0.04)",border:"2px solid #3b82f655",borderRadius:13,padding:16}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:13}}>
                    <div style={{display:"flex",alignItems:"center",gap:10}}>
                      <div style={{width:18,height:18,borderRadius:4,background:BLUE,flexShrink:0}}/>
                      <div style={{fontSize:19,fontWeight:800,color:BLUE}}>TEAM BLUE</div>
                    </div>
                    <div style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>Avg ★{avgSkill(teams[1])}</div>
                  </div>
                  {teams[1].map(p=>(
                    <div key={p.id} style={{display:"flex",alignItems:"center",gap:9,padding:"7px 0",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                      <div style={{width:28,height:28,borderRadius:7,background:pc(p.pos)+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:pc(p.pos)}}>{p.pos}</div>
                      <span style={{flex:1,fontWeight:700,fontSize:15}}>{p.name}</span>
                      {p.pos==="GK"&&<span style={{fontSize:10,background:"#3b82f622",color:BLUE,border:"1px solid #3b82f644",padding:"2px 7px",borderRadius:10,fontWeight:700}}>GK</span>}
                      <span style={{color:"#f59e0b",fontSize:12}}>★{p.skill}</span>
                    </div>
                  ))}
                  <div style={{marginTop:11,padding:"8px 11px",background:"#3b82f610",borderRadius:8,display:"flex",justifyContent:"space-between",fontSize:11,color:"rgba(255,255,255,0.35)"}}>
                    <span>{teams[1].length} players</span><span>Avg {avgSkill(teams[1])}/10</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ HISTORY ══ */}
        {tab==="History"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
              <div style={{fontSize:20,fontWeight:800}}>Session History</div>
              <Btn onClick={()=>{setSf({date:nextWed(),result:"",notes:"",ids:inP.length>0?inP.map(p=>p.id):[]});setSessionOpen(true);}}>+ Log Session</Btn>
            </div>
            {sessions.length===0&&<div style={{textAlign:"center",padding:"60px 0",color:"rgba(255,255,255,0.2)"}}><div style={{fontSize:50}}>📋</div><div style={{marginTop:12}}>No sessions yet</div></div>}
            {sessions.map(s=>{
              const played=players.filter(p=>s.playerIds?.includes(p.id));
              return(
                <div key={s.id} style={{background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:13,padding:16,marginBottom:10}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                    <div style={{fontWeight:800,fontSize:17}}>{new Date(s.date+"T12:00:00").toLocaleDateString("en-GB",{weekday:"short",day:"numeric",month:"long",year:"numeric"})}</div>
                    <span style={{fontSize:11,background:"rgba(59,130,246,0.15)",color:BLUE,padding:"2px 9px",borderRadius:20,fontWeight:700}}>{s.count} players</span>
                  </div>
                  {s.result&&<div style={{fontSize:14,color:"#f59e0b",fontWeight:700,marginBottom:8}}>📊 {s.result}</div>}
                  {played.length>0&&<div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:s.notes?8:0}}>{played.map(p=><span key={p.id} style={{background:pc(p.pos)+"18",color:pc(p.pos),border:"1px solid "+pc(p.pos)+"35",padding:"2px 9px",borderRadius:20,fontSize:12,fontWeight:600}}>{p.name}</span>)}</div>}
                  {s.notes&&<div style={{fontSize:13,color:"rgba(255,255,255,0.45)",fontStyle:"italic"}}>"{s.notes}"</div>}
                </div>
              );
            })}
          </div>
        )}

        {/* ══ STATS ══ */}
        {tab==="Stats"&&(
          <div>
            <div style={{fontSize:20,fontWeight:800,marginBottom:18}}>Squad Stats</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:4}}>
              {[{l:"APPEARANCES",v:players.reduce((s,p)=>s+p.games,0),c:BLUE},{l:"AVG SKILL",v:avgSkill(active),c:"#f59e0b"},{l:"SESSIONS",v:sessions.length,c:"#22c55e"}].map(x=>(
                <div key={x.l} style={{background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:12,padding:"13px 0",textAlign:"center"}}>
                  <div style={{fontSize:26,fontWeight:800,color:x.c}}>{x.v}</div>
                  <div style={{fontSize:9,color:"rgba(255,255,255,0.4)",letterSpacing:1,padding:"0 4px"}}>{x.l}</div>
                </div>
              ))}
            </div>
            <SLabel>🏆 Most Appearances</SLabel>
            {[...players].sort((a,b)=>b.games-a.games).map((p,i)=>(
              <div key={p.id} style={{display:"flex",alignItems:"center",gap:11,padding:"9px 0",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                <div style={{width:24,fontWeight:800,fontSize:15,color:["#f59e0b","#94a3b8","#cd7c4a"][i]||"rgba(255,255,255,0.2)"}}>#{i+1}</div>
                <div style={{width:30,height:30,borderRadius:7,background:pc(p.pos)+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:pc(p.pos)}}>{p.pos}</div>
                <div style={{flex:1,fontWeight:700}}>{p.name}</div>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{width:70,height:5,background:"rgba(255,255,255,0.08)",borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",width:Math.max(2,p.games/(Math.max(...players.map(q=>q.games),1)))*100+"%",background:BLUE,borderRadius:3}}/></div>
                  <span style={{fontWeight:800,color:BLUE,minWidth:24,textAlign:"right"}}>{p.games}</span>
                </div>
              </div>
            ))}
            <SLabel>⭐ Skill Rankings</SLabel>
            {[...players].sort((a,b)=>b.skill-a.skill).map((p,i)=>(
              <div key={p.id} style={{display:"flex",alignItems:"center",gap:11,padding:"9px 0",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                <div style={{width:24,fontWeight:800,fontSize:15,color:["#f59e0b","#94a3b8","#cd7c4a"][i]||"rgba(255,255,255,0.2)"}}>#{i+1}</div>
                <div style={{width:30,height:30,borderRadius:7,background:pc(p.pos)+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:pc(p.pos)}}>{p.pos}</div>
                <div style={{flex:1}}><div style={{fontWeight:700,marginBottom:4}}>{p.name}</div><SkillDots value={p.skill}/></div>
                <div style={{fontSize:17,fontWeight:800,color:"#f59e0b"}}>{p.skill}</div>
              </div>
            ))}
            <SLabel>🏟️ Position Breakdown</SLabel>
            <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:8,marginBottom:20}}>
              {POSITIONS.map(pos=>{const n=players.filter(p=>p.pos===pos).length;return(
                <div key={pos} style={{background:pc(pos)+"10",border:"1px solid "+pc(pos)+"30",borderRadius:11,padding:"11px 0",textAlign:"center"}}>
                  <div style={{fontSize:20,fontWeight:800,color:pc(pos)}}>{n}</div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.4)"}}>{pos}</div>
                </div>
              );})}
            </div>
            {sessions.length>0&&(()=>{
              const counts={};sessions.forEach(s=>{const m=s.date?.slice(0,7);if(m)counts[m]=(counts[m]||0)+1;});
              const mx=Math.max(...Object.values(counts));
              return(<><SLabel>📅 Sessions Per Month</SLabel>{Object.entries(counts).sort().map(([m,n])=>(
                <div key={m} style={{display:"flex",alignItems:"center",gap:11,padding:"7px 0",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                  <div style={{width:80,fontSize:12,color:"rgba(255,255,255,0.45)"}}>{new Date(m+"-15").toLocaleDateString("en-GB",{month:"short",year:"numeric"})}</div>
                  <div style={{flex:1,height:7,background:"rgba(255,255,255,0.08)",borderRadius:4,overflow:"hidden"}}><div style={{height:"100%",width:(n/mx)*100+"%",background:"#22c55e",borderRadius:4}}/></div>
                  <div style={{fontWeight:800,color:"#22c55e",minWidth:18}}>{n}</div>
                </div>
              ))}</>);
            })()}
          </div>
        )}
      </div>

      {/* ADD PLAYER MODAL */}
      {addOpen&&(<div className="mbg" onClick={()=>setAddOpen(false)}><div className="mbox" onClick={e=>e.stopPropagation()}>
        <div style={{fontSize:19,fontWeight:800,marginBottom:18}}>Add New Player</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <input style={iStyle} placeholder="Full name *" value={newP.name} onChange={e=>setNewP(p=>({...p,name:e.target.value}))}/>
          <select style={selStyle} value={newP.pos} onChange={e=>setNewP(p=>({...p,pos:e.target.value}))}>{POSITIONS.map(x=><option key={x}>{x}</option>)}</select>
          <div><div style={{fontSize:11,color:"#888",marginBottom:5}}>SKILL: {newP.skill}/10</div><input type="range" min={1} max={10} value={newP.skill} onChange={e=>setNewP(p=>({...p,skill:+e.target.value}))}/></div>
          <input style={iStyle} type="number" placeholder="Games already played (0)" value={newP.games||""} onChange={e=>setNewP(p=>({...p,games:+e.target.value||0}))}/>
          <div style={{display:"flex",gap:8,marginTop:4}}><Btn onClick={addPlayer} style={{flex:1}}>Add to Squad</Btn><Btn ghost onClick={()=>setAddOpen(false)}>Cancel</Btn></div>
        </div>
      </div></div>)}

      {/* LOG SESSION MODAL */}
      {sessionOpen&&(<div className="mbg" onClick={()=>setSessionOpen(false)}><div className="mbox" onClick={e=>e.stopPropagation()}>
        <div style={{fontSize:19,fontWeight:800,marginBottom:18}}>Log Session</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div><div style={{fontSize:10,color:"#888",letterSpacing:1,marginBottom:5}}>DATE</div><input style={iStyle} type="date" value={sf.date} onChange={e=>setSf(f=>({...f,date:e.target.value}))}/></div>
          <div><div style={{fontSize:10,color:"#888",letterSpacing:1,marginBottom:5}}>RESULT (optional)</div><input style={iStyle} placeholder="e.g. 7-5 or leave blank" value={sf.result} onChange={e=>setSf(f=>({...f,result:e.target.value}))}/></div>
          <div>
            <div style={{fontSize:10,color:"#888",letterSpacing:1,marginBottom:8}}>WHO PLAYED? <span style={{color:BLUE}}>({sf.ids.length} selected)</span></div>
            <div style={{display:"flex",gap:7,marginBottom:8}}>
              <Btn bg="rgba(34,197,94,0.15)" fg="#22c55e" sm onClick={()=>setSf(f=>({...f,ids:active.map(p=>p.id)}))}>All</Btn>
              <Btn ghost sm onClick={()=>setSf(f=>({...f,ids:[]}))}>Clear</Btn>
            </div>
            <div style={{maxHeight:190,overflowY:"auto",display:"flex",flexDirection:"column",gap:5}}>
              {active.map(p=>(
                <label key={p.id} style={{display:"flex",alignItems:"center",gap:9,cursor:"pointer",padding:"6px 8px",borderRadius:8,background:sf.ids.includes(p.id)?"rgba(34,197,94,0.1)":"transparent"}}>
                  <input type="checkbox" checked={sf.ids.includes(p.id)} onChange={()=>setSf(f=>({...f,ids:f.ids.includes(p.id)?f.ids.filter(x=>x!==p.id):[...f.ids,p.id]}))}/>
                  <span style={{flex:1,fontWeight:600}}>{p.name}</span>
                  <span style={{fontSize:11,color:pc(p.pos)}}>{p.pos}</span>
                </label>
              ))}
            </div>
          </div>
          <div><div style={{fontSize:10,color:"#888",letterSpacing:1,marginBottom:5}}>NOTES (optional)</div><textarea value={sf.notes} onChange={e=>setSf(f=>({...f,notes:e.target.value}))} rows={2} placeholder="Any notes..." style={{...iStyle,resize:"vertical"}}/></div>
          <div style={{fontSize:12,color:"rgba(255,255,255,0.3)",background:"rgba(59,130,246,0.07)",border:"1px solid rgba(59,130,246,0.18)",borderRadius:8,padding:"8px 11px"}}>ℹ️ Saves session and adds +1 game to each selected player</div>
          <div style={{display:"flex",gap:8}}><Btn onClick={logSession} style={{flex:1}}>Save Session</Btn><Btn ghost onClick={()=>setSessionOpen(false)}>Cancel</Btn></div>
        </div>
      </div></div>)}
    </div>
  );
}
